package com.test.java;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractGolfGame implements IGolfGame {
    protected String date;
    protected List<String> players;
    protected int roundCount;
    protected Map<String, List<Integer>> scores;

    public AbstractGolfGame(String date, List<String> players, int roundCount) {
        this.date = date;
        this.players = players;
        this.roundCount = roundCount;
        this.scores = new HashMap<>();
        for (String player : players) {
            scores.put(player, new ArrayList<>());
        }
    }

    @Override
    public String getDate() {
        return date;
    }

    @Override
    public List<String> getPlayers() {
        return players;
    }

    @Override
    public int getRoundCount() {
        return roundCount;
    }

    @Override
    public Map<String, List<Integer>> getScores() {
        return scores;
    }

    @Override
    public void addScore(String player, int score) {
        scores.get(player).add(score);
    }
}