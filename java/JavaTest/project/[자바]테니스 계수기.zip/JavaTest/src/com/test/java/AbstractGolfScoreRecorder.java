package com.test.java;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractGolfScoreRecorder implements IGolfScoreRecorder {
    protected static final String MEMBER_FILE = "member.txt";
    protected static final String SCORE_FILE = "score.txt";
    protected static final String HOLE_FILE = "hole.txt";
    protected static final String GAMES_FILE = "games.txt";

    protected List<Integer> holePars = new ArrayList<>();
    protected List<IGolfGame> games = new ArrayList<>();

    @Override
    public List<IGolfGame> getGames() {
        return games;
    }

    protected abstract String getScoreDescription(int score, int par);
    protected abstract void displayGameScore(IGolfGame game);
    protected abstract void pauseBeforeMainMenu();
}