package com.test.java;

public interface ColoredOutput {
    void printRed(String message);
    void printGreen(String message);
    void printYellow(String message);
    void printBlue(String message);
    void printPurple(String message);
    void printCyan(String message);

    String getRedText(String text);
    String getGreenText(String text);
    String getYellowText(String text);
    String getBlueText(String text);
    String getPurpleText(String text);
    String getCyanText(String text);
}