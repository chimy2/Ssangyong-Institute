package com.test.java;

public class ConsoleColoredOutput implements ColoredOutput {
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_BLUE = "\u001B[34m";
    private static final String ANSI_PURPLE = "\u001B[35m";
    private static final String ANSI_CYAN = "\u001B[36m";

    @Override
    public void printRed(String message) {
        System.out.println(ANSI_RED + message + ANSI_RESET);
    }

    @Override
    public void printGreen(String message) {
        System.out.println(ANSI_GREEN + message + ANSI_RESET);
    }

    @Override
    public void printYellow(String message) {
        System.out.println(ANSI_YELLOW + message + ANSI_RESET);
    }

    @Override
    public void printBlue(String message) {
        System.out.println(ANSI_BLUE + message + ANSI_RESET);
    }

    @Override
    public void printPurple(String message) {
        System.out.println(ANSI_PURPLE + message + ANSI_RESET);
    }

    @Override
    public void printCyan(String message) {
        System.out.println(ANSI_CYAN + message + ANSI_RESET);
    }

    @Override
    public String getRedText(String text) {
        return ANSI_RED + text + ANSI_RESET;
    }

    @Override
    public String getGreenText(String text) {
        return ANSI_GREEN + text + ANSI_RESET;
    }

    @Override
    public String getYellowText(String text) {
        return ANSI_YELLOW + text + ANSI_RESET;
    }

    @Override
    public String getBlueText(String text) {
        return ANSI_BLUE + text + ANSI_RESET;
    }

    @Override
    public String getPurpleText(String text) {
        return ANSI_PURPLE + text + ANSI_RESET;
    }

    @Override
    public String getCyanText(String text) {
        return ANSI_CYAN + text + ANSI_RESET;
    }
}