package com.test.java;

import java.util.List;

public class GolfGame extends AbstractGolfGame {
    public GolfGame(String date, List<String> players, int roundCount) {
        super(date, players, roundCount);
    }
}