package com.test.java;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class GolfScoreRecorder extends AbstractGolfScoreRecorder {
    private Scanner scanner = new Scanner(System.in);
    private ColoredOutput coloredOutput;

    public GolfScoreRecorder(ColoredOutput coloredOutput) {
        this.coloredOutput = coloredOutput;
    }

    @Override
    public void initializeHolePars() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(HOLE_FILE))) {
            for (int i = 1; i <= 18; i++) {
                int par = (i % 3 == 0) ? 5 : (i % 3 == 1) ? 4 : 3;
                holePars.add(par);
                writer.println(i + "," + par);
            }
            coloredOutput.printGreen("홀 정보가 초기화되었습니다.");
        } catch (IOException e) {
            coloredOutput.printYellow("홀 정보 저장 중 오류 발생: " + e.getMessage());
        }
    }

    @Override
    public void recordNewGame() {
        coloredOutput.printBlue("\n┌─────────────────── 새 게임 기록 ───────────────────┐");
        coloredOutput.printBlue("│ 새로운 골프 게임의 스코어를 기록합니다.               │");
        coloredOutput.printBlue("│ 각 플레이어의 이름과 각 홀의 스코어를 입력하세요.     │");
        coloredOutput.printBlue("└────────────────────────────────────────────────────┘");

        coloredOutput.printPurple("\n\uD83D\uDC65 플레이어 수 (1 또는 2): ");
        int playerCount = getUserChoice(1, 2);

        List<String> players = new ArrayList<>();
        for (int i = 0; i < playerCount; i++) {
            coloredOutput.printPurple("\uD83C\uDFCC 플레이어 " + (i + 1) + " 이름: ");
            players.add(scanner.nextLine());
        }

        coloredOutput.printPurple("\n\uD83C\uDFC1 라운드 수 (9 또는 18): ");
        int roundCount = getUserChoice(9, 18);

        String date = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
        IGolfGame game = new GolfGame(date, players, roundCount);

        for (int i = 0; i < roundCount; i++) {
            int par = holePars.get(i);
            coloredOutput.printYellow("\n\u26F3 " + (i + 1) + "번 홀 (파 " + par + ")");
            for (String player : players) {
                coloredOutput.printPurple(player + "의 스코어 (파 " + par + "): ");
                int score = getUserChoice(1, 10); // 1에서 10까지의 스코어 허용
                game.addScore(player, score);

                String result = getScoreDescription(score, par);
                System.out.println(result);
            }
        }

        games.add(game);
        saveGames();
        coloredOutput.printGreen("\n\u2705 게임 기록이 성공적으로 저장되었습니다!");
    }

    @Override
    public void viewRecords() {
        coloredOutput.printBlue("\n=== 기록 열람 ===");
        if (games.isEmpty()) {
            coloredOutput.printYellow("저장된 게임이 없습니다.");
            return;
        }

        for (int i = 0; i < games.size(); i++) {
            IGolfGame game = games.get(i);
            System.out.printf("%d. %s (%d라운드, 플레이어: %s)\n", i + 1, game.getDate(), game.getRoundCount(), String.join(", ", game.getPlayers()));
        }

        coloredOutput.printPurple("열람할 게임 번호를 선택하세요: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // 버퍼 비우기

        if (choice < 1 || choice > games.size()) {
            coloredOutput.printYellow("잘못된 선택입니다.");
            return;
        }

        IGolfGame selectedGame = games.get(choice - 1);
        displayGameScore(selectedGame);
    }

    @Override
    public void saveGames() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(GAMES_FILE))) {
            for (IGolfGame game : games) {
                writer.println(game.getDate() + "," + game.getRoundCount() + "," + String.join(",", game.getPlayers()));
                for (String player : game.getPlayers()) {
                    writer.println(player + ":" + game.getScores().get(player).stream().map(String::valueOf).collect(Collectors.joining(",")));
                }
                writer.println(); // 게임 구분을 위한 빈 줄
            }
        } catch (IOException e) {
            coloredOutput.printYellow("게임 저장 중 오류 발생: " + e.getMessage());
        }
    }

    @Override
    protected String getScoreDescription(int score, int par) {
        int difference = score - par;
        switch (difference) {
            case -4:
                return coloredOutput.getGreenText("콘도르!");
            case -3:
                return coloredOutput.getGreenText("알바트로스!");
            case -2:
                return coloredOutput.getGreenText("이글!");
            case -1:
                return coloredOutput.getGreenText("버디!");
            case 0:
                return coloredOutput.getBlueText("파!");
            case 1:
                return coloredOutput.getYellowText("보기");
            case 2:
                return coloredOutput.getYellowText("더블 보기");
            case 3:
                return coloredOutput.getYellowText("트리플 보기");
            default:
                if (difference < -4) {
                    return coloredOutput.getGreenText("콘도르 이상의 대기록!");
                } else {
                    return coloredOutput.getYellowText("트리플 보기 이상");
                }
        }
    }

    @Override
    protected void displayGameScore(IGolfGame game) {
        coloredOutput.printBlue("\n┌───────────────── " + game.getDate() + " 게임 기록 ─────────────────┐");
        coloredOutput.printBlue("│ 라운드 수: " + game.getRoundCount() + "                                           │");
        coloredOutput.printBlue("├─────────┬" + "─".repeat(game.getRoundCount() * 4 + 1) + "┬───────┬───────┤");

        // 표 헤더
        System.out.print("│플레이어 │");
        for (int i = 1; i <= game.getRoundCount(); i++) {
            System.out.printf("%2d│", i);
        }
        System.out.print(" 총점 │ 대비 │");
        coloredOutput.printBlue("\n├─────────┼" + "─".repeat(game.getRoundCount() * 4 + 1) + "┼───────┼───────┤");

        // 각 플레이어의 스코어
        for (String player : game.getPlayers()) {
            System.out.printf("│%-9s│", player);
            List<Integer> playerScores = game.getScores().get(player);
            int totalScore = 0;
            int totalPar = 0;
            for (int i = 0; i < game.getRoundCount(); i++) {
                int score = playerScores.get(i);
                int par = holePars.get(i);
                totalScore += score;
                totalPar += par;
                String scoreStr = getColoredScore(score, par);
                System.out.printf("%2s│", scoreStr);
            }
            System.out.printf("%4d  │%+4d  │", totalScore, totalScore - totalPar);
            coloredOutput.printBlue("\n├─────────┼" + "─".repeat(game.getRoundCount() * 4 + 1) + "┼───────┼───────┤");
        }

        // 파 정보 표시
        System.out.print("│파       │");
        int totalPar = 0;
        for (int i = 0; i < game.getRoundCount(); i++) {
            int par = holePars.get(i);
            totalPar += par;
            System.out.printf("%2d│", par);
        }
        System.out.printf("%4d  │      │", totalPar);
        coloredOutput.printBlue("\n└─────────┴" + "─".repeat(game.getRoundCount() * 4 + 1) + "┴───────┴───────┘");

        coloredOutput.printYellow("\n\uD83C\uDFC6 스코어 가이드:");
        coloredOutput.printGreen("   \uD83E\uDD85 이글 이상    \uD83D\uDC26 버디    \uD83D\uDFE6 파    \uD83D\uDFE8 보기    \uD83D\uDFE5 더블보기 이상");
    }

    private String getColoredScore(int score, int par) {
        int difference = score - par;
        String scoreStr = String.valueOf(score);
        if (difference <= -3) return coloredOutput.getGreenText(scoreStr);
        if (difference == -2) return coloredOutput.getBlueText(scoreStr);
        if (difference == -1) return coloredOutput.getCyanText(scoreStr);
        if (difference == 0) return scoreStr;
        if (difference == 1) return coloredOutput.getYellowText(scoreStr);
        return coloredOutput.getRedText(scoreStr);
    }

    @Override
    protected void pauseBeforeMainMenu() {
        coloredOutput.printYellow("\n엔터를 누르면 메인 메뉴로 돌아갑니다...");
        scanner.nextLine(); // 사용자 입력 대기
    }

    private int getUserChoice(int min, int max) {
        int choice;
        while (true) {
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice >= min && choice <= max) {
                    return choice;
                }
                coloredOutput.printRed("잘못된 입력입니다. " + min + "에서 " + max + " 사이의 숫자를 입력해주세요.");
            } catch (NumberFormatException e) {
                coloredOutput.printRed("숫자를 입력해주세요.");
            }
            coloredOutput.printPurple("다시 선택해주세요: ");
        }
    }
}