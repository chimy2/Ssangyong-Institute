package com.test.java;

import java.util.Scanner;

public class GolfScoreRecorderApp {
    private static IGolfScoreRecorder recorder;
    private static ColoredOutput coloredOutput;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        coloredOutput = new ConsoleColoredOutput();
        recorder = new GolfScoreRecorder(coloredOutput);
        recorder.initializeHolePars();

        while (true) {
            printMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // 버퍼 비우기

            switch (choice) {
                case 1:
                    recorder.recordNewGame();
                    pauseBeforeMainMenu();
                    break;
                case 2:
                    recorder.viewRecords();
                    pauseBeforeMainMenu();
                    break;
                case 3:
                    coloredOutput.printYellow("프로그램을 종료합니다. 안녕히 가세요!");
                    return;
                default:
                    coloredOutput.printYellow("잘못된 선택입니다. 다시 선택해주세요.");
                    pauseBeforeMainMenu();
            }
        }
    }

    private static void printMainMenu() {
        String logo =
                "   \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3\n" +
                        "   ____       _  __ ____                        _           \n" +
                        "  / ___| ___ | |/ // ___|  ___ ___  _ __ ___   | |__  _   _ \n" +
                        " | |  _ / _ \\| ' / \\___ \\ / __/ _ \\| '__/ _ \\  | '_ \\| | | |\n" +
                        " | |_| | (_) | . \\  ___) | (_| (_) | | |  __/  | |_) | |_| |\n" +
                        "  \\____|\\___/|_|\\_\\|____/ \\___\\___/|_|  \\___|  |_.__/ \\__, |\n" +
                        "                                                      |___/ \n" +
                        "   \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3 \uD83C\uDFCC \u26F3";

        coloredOutput.printGreen(logo);
        coloredOutput.printBlue("\n┌─────────────────── 골프 스코어 기록 프로그램 ───────────────────┐");
        coloredOutput.printBlue("│                                                                │");
        coloredOutput.printBlue("│  1. \uD83D\uDCDD 새 게임 기록     - 새로운 골프 게임의 스코어를 기록합니다.    │");
        coloredOutput.printBlue("│  2. \uD83D\uDCCA 기록 열람        - 저장된 게임 기록을 조회합니다.            │");
        coloredOutput.printBlue("│  3. \uD83D\uDEAA 종료            - 프로그램을 종료합니다.                   │");
        coloredOutput.printBlue("│                                                                │");
        coloredOutput.printBlue("└────────────────────────────────────────────────────────────────┘");
        coloredOutput.printPurple("\n메뉴를 선택하세요 (1-3): ");
    }

    private static void pauseBeforeMainMenu() {
        coloredOutput.printYellow("\n엔터를 누르면 메인 메뉴로 돌아갑니다...");
        scanner.nextLine(); // 사용자 입력 대기
    }
}