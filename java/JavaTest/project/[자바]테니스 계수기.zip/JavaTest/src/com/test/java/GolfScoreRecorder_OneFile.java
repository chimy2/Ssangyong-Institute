package com.test.java;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class GolfScoreRecorder_OneFile {
    private static final String MEMBER_FILE = "member.txt";
    private static final String SCORE_FILE = "score.txt";
    private static final String HOLE_FILE = "hole.txt";

    private static List<Integer> holePars = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // ANSI 색상 코드
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_BLACK = "\u001B[30m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_BLUE = "\u001B[34m";
    private static final String ANSI_PURPLE = "\u001B[35m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_WHITE = "\u001B[37m";

    private static class Game {
        String date;
        List<String> players;
        int roundCount;
        Map<String, List<Integer>> scores;

        Game(String date, List<String> players, int roundCount) {
            this.date = date;
            this.players = players;
            this.roundCount = roundCount;
            this.scores = new HashMap<>();
            for (String player : players) {
                scores.put(player, new ArrayList<>());
            }
        }
    }

    private static List<Game> games = new ArrayList<>();
    private static final String GAMES_FILE = "games.txt";

    public static void main(String[] args) {
        initializeHolePars();
        loadGames();
        while (true) {
            printMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // 버퍼 비우기

            switch (choice) {
                case 1:
                    recordNewGame();
                    pauseBeforeMainMenu();
                    break;
                case 2:
                    viewRecords();
                    pauseBeforeMainMenu();
                    break;
                case 3:
                    System.out.println(ANSI_YELLOW + "프로그램을 종료합니다. 안녕히 가세요!" + ANSI_RESET);
                    return;
                default:
                    System.out.println(ANSI_YELLOW + "잘못된 선택입니다. 다시 선택해주세요." + ANSI_RESET);
                    pauseBeforeMainMenu();
            }
        }
    }

    private static void loadGames() {
        try (BufferedReader reader = new BufferedReader(new FileReader(GAMES_FILE))) {
            String line;
            Game currentGame = null;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) {
                    if (currentGame != null) {
                        games.add(currentGame);
                        currentGame = null;
                    }
                    continue;
                }
                if (currentGame == null) {
                    String[] parts = line.split(",");
                    String date = parts[0];
                    int roundCount = Integer.parseInt(parts[1]);
                    List<String> players = Arrays.asList(Arrays.copyOfRange(parts, 2, parts.length));
                    currentGame = new Game(date, players, roundCount);
                } else {
                    String[] parts = line.split(":");
                    String player = parts[0];
                    List<Integer> scores = Arrays.stream(parts[1].split(","))
                            .map(Integer::parseInt)
                            .collect(Collectors.toList());
                    currentGame.scores.put(player, scores);
                }
            }
            if (currentGame != null) {
                games.add(currentGame);
            }
        } catch (IOException e) {
            System.out.println(ANSI_YELLOW + "게임 로드 중 오류 발생: " + e.getMessage() + ANSI_RESET);
        }
    }

    private static void printMainMenu() {
        System.out.println("\n" + ANSI_GREEN +
                "   ____       _  __ ____                        _           \n" +
                "  / ___| ___ | |/ // ___|  ___ ___  _ __ ___   | |__  _   _ \n" +
                " | |  _ / _ \\| ' / \\___ \\ / __/ _ \\| '__/ _ \\  | '_ \\| | | |\n" +
                " | |_| | (_) | . \\  ___) | (_| (_) | | |  __/  | |_) | |_| |\n" +
                "  \\____|\\___/|_|\\_\\|____/ \\___\\___/|_|  \\___|  |_.__/ \\__, |\n" +
                "                                                      |___/ " + ANSI_RESET);
        System.out.println(ANSI_BLUE + "=== 골프 스코어 기록 프로그램 ===" + ANSI_RESET);
        System.out.println(ANSI_YELLOW + "1. 새 게임 기록");
        System.out.println("2. 기록 열람");
        System.out.println("3. 종료" + ANSI_RESET);
        System.out.print(ANSI_PURPLE + "선택해주세요 (1-3): " + ANSI_RESET);
    }

    private static void initializeHolePars() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(HOLE_FILE))) {
            for (int i = 1; i <= 18; i++) {
                int par = (i % 3 == 0) ? 5 : (i % 3 == 1) ? 4 : 3;
                holePars.add(par);
                writer.println(i + "," + par);
            }
            System.out.println(ANSI_GREEN + "홀 정보가 초기화되었습니다." + ANSI_RESET);
        } catch (IOException e) {
            System.out.println(ANSI_YELLOW + "홀 정보 저장 중 오류 발생: " + e.getMessage() + ANSI_RESET);
        }
    }

    private static void recordNewGame() {
        System.out.println(ANSI_BLUE + "\n=== 새 게임 기록 ===" + ANSI_RESET);
        System.out.print(ANSI_PURPLE + "플레이어 수 (1 또는 2): " + ANSI_RESET);
        int playerCount = scanner.nextInt();
        scanner.nextLine(); // 버퍼 비우기

        List<String> players = new ArrayList<>();
        for (int i = 0; i < playerCount; i++) {
            System.out.print(ANSI_PURPLE + "플레이어 " + (i + 1) + " 이름: " + ANSI_RESET);
            players.add(scanner.nextLine());
        }

        System.out.print(ANSI_PURPLE + "라운드 수 (9 또는 18): " + ANSI_RESET);
        int roundCount = scanner.nextInt();
        scanner.nextLine(); // 버퍼 비우기

        String date = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
        Game game = new Game(date, players, roundCount);

        for (int i = 0; i < roundCount; i++) {
            int par = holePars.get(i);
            System.out.println(ANSI_YELLOW + "\n=== " + (i + 1) + "번 홀 (파 " + par + ") ===" + ANSI_RESET);
            for (String player : players) {
                System.out.print(ANSI_PURPLE + player + "의 스코어 (파 " + par + "): " + ANSI_RESET);
                int score = scanner.nextInt();
                game.scores.get(player).add(score);

                String result = getScoreDescription(score, par);
                System.out.println(result);
            }
        }

        games.add(game);
        saveGames();
        System.out.println(ANSI_GREEN + "게임 기록이 성공적으로 저장되었습니다!" + ANSI_RESET);
    }

    private static void saveGames() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(GAMES_FILE))) {
            for (Game game : games) {
                writer.println(game.date + "," + game.roundCount + "," + String.join(",", game.players));
                for (String player : game.players) {
                    writer.println(player + ":" + game.scores.get(player).stream().map(String::valueOf).collect(Collectors.joining(",")));
                }
                writer.println(); // 게임 구분을 위한 빈 줄
            }
        } catch (IOException e) {
            System.out.println(ANSI_YELLOW + "게임 저장 중 오류 발생: " + e.getMessage() + ANSI_RESET);
        }
    }

    private static String getScoreDescription(int score, int par) {
        int difference = score - par;
        switch (difference) {
            case -4:
                return ANSI_GREEN + "콘도르!" + ANSI_RESET;
            case -3:
                return ANSI_GREEN + "알바트로스!" + ANSI_RESET;
            case -2:
                return ANSI_GREEN + "이글!" + ANSI_RESET;
            case -1:
                return ANSI_GREEN + "버디!" + ANSI_RESET;
            case 0:
                return ANSI_BLUE + "파!" + ANSI_RESET;
            case 1:
                return ANSI_YELLOW + "보기" + ANSI_RESET;
            case 2:
                return ANSI_YELLOW + "더블 보기" + ANSI_RESET;
            case 3:
                return ANSI_YELLOW + "트리플 보기" + ANSI_RESET;
            default:
                if (difference < -4) {
                    return ANSI_GREEN + "콘도르 이상의 대기록!" + ANSI_RESET;
                } else {
                    return ANSI_YELLOW + "트리플 보기 이상" + ANSI_RESET;
                }
        }
    }

    private static void viewRecords() {
        System.out.println(ANSI_BLUE + "\n=== 기록 열람 ===" + ANSI_RESET);
        if (games.isEmpty()) {
            System.out.println(ANSI_YELLOW + "저장된 게임이 없습니다." + ANSI_RESET);
            return;
        }

        for (int i = 0; i < games.size(); i++) {
            Game game = games.get(i);
            System.out.printf("%d. %s (%d라운드, 플레이어: %s)\n", i + 1, game.date, game.roundCount, String.join(", ", game.players));
        }

        System.out.print(ANSI_PURPLE + "열람할 게임 번호를 선택하세요: " + ANSI_RESET);
        int choice = scanner.nextInt();
        scanner.nextLine(); // 버퍼 비우기

        if (choice < 1 || choice > games.size()) {
            System.out.println(ANSI_YELLOW + "잘못된 선택입니다." + ANSI_RESET);
            return;
        }

        Game selectedGame = games.get(choice - 1);
        displayGameScore(selectedGame);
    }

    private static void displayGameScore(Game game) {
        System.out.println(ANSI_BLUE + "\n=== " + game.date + " 게임 기록 ===" + ANSI_RESET);
        System.out.println("라운드 수: " + game.roundCount);

        // 표 헤더
        System.out.print("플레이어 |");
        for (int i = 1; i <= game.roundCount; i++) {
            System.out.printf(" %2d |", i);
        }
        System.out.print(" 총점 | 대비 |");
        System.out.println("\n" + "-".repeat(10 + game.roundCount * 5 + 13));

        // 각 플레이어의 스코어
        for (String player : game.players) {
            System.out.printf("%-9s|", player);
            List<Integer> playerScores = game.scores.get(player);
            int totalScore = 0;
            int totalPar = 0;
            for (int i = 0; i < game.roundCount; i++) {
                int score = playerScores.get(i);
                int par = holePars.get(i);
                totalScore += score;
                totalPar += par;
                String scoreStr = getColoredScore(score, par);
                System.out.printf(" %2s |", scoreStr);
            }
            System.out.printf(" %3d  | %+3d  |", totalScore, totalScore - totalPar);
            System.out.println();
        }
        System.out.println("-".repeat(10 + game.roundCount * 5 + 13));

        // 파 정보 표시
        System.out.print("파       |");
        int totalPar = 0;
        for (int i = 0; i < game.roundCount; i++) {
            int par = holePars.get(i);
            totalPar += par;
            System.out.printf(" %2d |", par);
        }
        System.out.printf(" %3d  |     |", totalPar);
        System.out.println();
    }

    private static String getColoredScore(int score, int par) {
        int difference = score - par;
        String scoreStr = String.valueOf(score);
        if (difference <= -3) return ANSI_GREEN + scoreStr + ANSI_RESET;
        if (difference == -2) return ANSI_BLUE + scoreStr + ANSI_RESET;
        if (difference == -1) return ANSI_CYAN + scoreStr + ANSI_RESET;
        if (difference == 0) return scoreStr;
        if (difference == 1) return ANSI_YELLOW + scoreStr + ANSI_RESET;
        return ANSI_RED + scoreStr + ANSI_RESET;
    }


    private static void pauseBeforeMainMenu() {
        System.out.print(ANSI_YELLOW + "\n엔터를 누르면 메인 메뉴로 돌아갑니다..." + ANSI_RESET);
        scanner.nextLine(); // 사용자 입력 대기
    }
}


