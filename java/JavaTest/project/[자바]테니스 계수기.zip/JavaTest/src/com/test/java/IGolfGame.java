package com.test.java;

import java.util.List;
import java.util.Map;

public interface IGolfGame {
    String getDate();
    List<String> getPlayers();
    int getRoundCount();
    Map<String, List<Integer>> getScores();
    void addScore(String player, int score);
}