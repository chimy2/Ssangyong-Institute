package com.test.java;

import java.util.List;

public interface IGolfScoreRecorder {
    void initializeHolePars();
    void recordNewGame();
    void viewRecords();
    void saveGames();
    List<IGolfGame> getGames();
}