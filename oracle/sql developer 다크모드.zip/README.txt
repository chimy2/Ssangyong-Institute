C:\Users\9550\AppData\Roaming\SQL Developer\system18.4.0.376.1900\o.ide.13.0.0.1.42.170225.201
dtcache.xml(+)

ozbsidian-scheme.xml